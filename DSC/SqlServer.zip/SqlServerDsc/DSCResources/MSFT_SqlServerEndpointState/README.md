# DEPRECATION NOTICE

The `SqlServerEndpointState` DSC resource is **DEPRECATED**. The resource
is replaced by a property in the resource `SqlServerEndpoint`.

The documentation, examples, unit test, and integration tests have been
removed. This resource will be removed in a future release.
